Mime::Type.register_alias 'text/html', :iphone
