Setting.update_all if Setting.table_exists?
