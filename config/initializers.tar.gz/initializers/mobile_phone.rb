MOBILE_GATEWAYS = {
  'AT&T' => '%s@txt.att.net',
  'CellularOne' => '%s@mobile.celloneusa.com',
  'Nextel' => '%s@messaging.nextel.com',
  'Sprint' => '%s@messaging.sprintpcs.com',
  'T-Mobile' => '%s@tmomail.net',
  'US Cellular' => '%s@email.uscc.net',
  'Verizon' => '%s@vtext.com',
  'Virgin Mobile' => '%s@vmobl.com',
}
