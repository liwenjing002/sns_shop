# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OneBody::Application.config.secret_token = '97230925d117b4c2959e6077b16e53dbdc25816582db8ad90985481b740d0cbe57d13bd648add18387e7bbd026696a2ef7b145a47488975d1a91ccadfb039ce3'
