DAYS_NEW = 7
MAX_FRIENDS_ON_PROFILE = 5
MAX_GROUPIES_ON_PROFILE = 5
BIRTHDAY_SOON_DAYS = 30
MAX_PEOPLE_IN_SMALL_GROUP = 75 # if more than this, then group is considered not "small"
